function toggleDropdown() {
    var phoneNumber = document.querySelector('.phone-number');
    phoneNumber.classList.toggle('active');
}
const carousel = document.querySelector(".carousel"),
firstImg = carousel.querySelectorAll("img")[0],
arrowIcons = document.querySelectorAll(".wrapper i");
let isDragStart = false, isDragging = false, prevPageX, prevScrollLeft, positionDiff;
const showHideIcons = () => {
    let scrollWidth = carousel.scrollWidth - carousel.clientWidth;
    arrowIcons[0].style.display = carousel.scrollLeft == 0 ? "none" : "block";
    arrowIcons[1].style.display = carousel.scrollLeft == scrollWidth ? "none" : "block";
}
arrowIcons.forEach(icon => {
    icon.addEventListener("click", () => {
        let firstImgWidth = firstImg.clientWidth + 14; 
        carousel.scrollLeft += icon.id == "left" ? -firstImgWidth : firstImgWidth;
        setTimeout(() => showHideIcons(), 60); 
    });
});
const carousel_two = document.querySelector(".carousel-two"),
firstImg_two = carousel_two.querySelectorAll("img")[0],
arrowIcons_two = document.querySelectorAll(".wrapper-two i");
let isDragStart__two = false, 
isDragging__two = false,
prevPageX__two, 
prevScrollLeft__two, 
positionDiff__two;
const showHideIcons__two = () => {
    let scrollWidth = carousel_two.scrollWidth - carousel_two.clientWidth;
    arrowIcons_two[0].style.display = carousel_two.scrollLeft == 0 ? "none" : "block";
    arrowIcons_two[1].style.display = carousel_two.scrollLeft == scrollWidth ? "none" : "block";
}
arrowIcons_two.forEach(icon => {
    icon.addEventListener("click", () => {
        let firstImgWidth = firstImg_two.clientWidth + 14; 
        carousel_two.scrollLeft += icon.id == "left_two" ? -firstImgWidth : firstImgWidth;
        setTimeout(() => showHideIcons__two(), 60); 
    });
});
